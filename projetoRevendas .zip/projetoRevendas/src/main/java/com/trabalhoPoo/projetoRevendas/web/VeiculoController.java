package com.trabalhoPoo.projetoRevendas.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trabalhoPoo.projetoRevendas.domain.Veiculo;
import com.trabalhoPoo.projetoRevendas.domain.VeiculoRepositorio;

@RestController
public class VeiculoController {
	@Autowired
	private VeiculoRepositorio repositorio3;

	@RequestMapping("/veiculos")
	public Iterable<Veiculo> getCliente() {
		return repositorio3.findAll();
	}
}
