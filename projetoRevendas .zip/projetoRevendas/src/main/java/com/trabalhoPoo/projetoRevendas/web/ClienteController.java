package com.trabalhoPoo.projetoRevendas.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trabalhoPoo.projetoRevendas.domain.Cliente;
import com.trabalhoPoo.projetoRevendas.domain.ClienteRepositorio;

@RestController
public class ClienteController {
	@Autowired
	private ClienteRepositorio repositorio;

	@RequestMapping("/clientes")
	public Iterable<Cliente> getCliente() {
		return repositorio.findAll();
	}
}
