package com.trabalhoPoo.projetoRevendas.domain;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "PedidoVendatb")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class PedidoVenda {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int codigo;
	private Date data;
	private float valorPedido;
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "cliente")
	private Cliente cliente; 
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "vendedor")
	private Vendedor vendedor;
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "veiculo")
	private Veiculo veiculo;
	@OneToMany(cascade = CascadeType.ALL, mappedBy="pedidovenda")
	@JsonIgnore
	private List<ItemPedido> itens;
	
	
	public PedidoVenda() {}

	public PedidoVenda(int codigo, float valorPedido, Cliente cliente, Vendedor vendedor, Veiculo veiculo){
		super();
		this.codigo = codigo;
		this.data = d;
		this.valorPedido = valorPedido;
		this.cliente = cliente;
		this.vendedor = vendedor;
		this.veiculo = veiculo;
	}
	
	Calendar c = Calendar.getInstance();
	Date d = c.getTime();

	public int getId() {
		return id;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public float getValorPedido() {
		return valorPedido;
	}

	public void setValorPedido(float valorPedido) {
		this.valorPedido = valorPedido;
	}

	public List<ItemPedido> getItens() {
		return itens;
	}

	public void setItens(List<ItemPedido> item) {
		this.itens = item;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public Veiculo getVeiculo() {
		return veiculo;
	}

	public void setVeiculo(Veiculo veiculo) {
		this.veiculo = veiculo;
	}

	public float calcularPedido() {

		float valorPedido = 0;

		for (ItemPedido i : this.itens) {

			valorPedido += (i.getValor() * i.getQuantidade());
		}

		return valorPedido;
	}
	
}
