package com.trabalhoPoo.projetoRevendas.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trabalhoPoo.projetoRevendas.domain.PedidoVendaRepositorio;
import com.trabalhoPoo.projetoRevendas.domain.PedidoVenda;

@RestController
public class PedidoVendaController {
	@Autowired
	private PedidoVendaRepositorio repositorio4;

	@RequestMapping("/pedidos")
	public Iterable<PedidoVenda> getPedidos() {
		return repositorio4.findAll();
	}
}
