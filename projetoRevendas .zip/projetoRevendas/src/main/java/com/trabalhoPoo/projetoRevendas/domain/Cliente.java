package com.trabalhoPoo.projetoRevendas.domain;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name= "Clientetb")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Cliente {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int codigo;
	private String nome;
	private int tipoCliente;
	@OneToOne(cascade = CascadeType.ALL, mappedBy="cliente")
	@JsonIgnore
	private PedidoVenda pedidos;
	
	public Cliente() {}
	
	public Cliente(int codigo, String nome, int tipoCliente) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.tipoCliente = tipoCliente;
	}
	
	public int getId() {
		return id;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getTipoCliente() {
		return tipoCliente;
	}

	public void setTipoCliente(int tipoCliente) {
		this.tipoCliente = tipoCliente;
	}
	
	public PedidoVenda getPedidos() {
		return pedidos;
	}

	public void setPedidos(PedidoVenda pedidos) {
		this.pedidos = pedidos;
	}
	
}
