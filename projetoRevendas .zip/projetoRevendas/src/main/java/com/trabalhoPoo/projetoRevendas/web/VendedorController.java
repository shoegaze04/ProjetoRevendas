package com.trabalhoPoo.projetoRevendas.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trabalhoPoo.projetoRevendas.domain.Vendedor;
import com.trabalhoPoo.projetoRevendas.domain.VendedorRepositorio;

@RestController
public class VendedorController {
	@Autowired
	private VendedorRepositorio repositorio2;

	@RequestMapping("/vendedores")
	public Iterable<Vendedor> getCliente() {
		return repositorio2.findAll();
	}
}
