package com.trabalhoPoo.projetoRevendas.domain;

import org.springframework.data.repository.CrudRepository;

public interface PedidoVendaRepositorio extends CrudRepository<PedidoVenda, Long>{

}
