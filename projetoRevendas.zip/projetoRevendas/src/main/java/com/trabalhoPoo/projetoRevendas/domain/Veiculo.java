package com.trabalhoPoo.projetoRevendas.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name= "Veiculotb")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Veiculo {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int codigo;
	private String descricao;
	private float valor;
	@OneToMany(cascade = CascadeType.ALL, mappedBy="veiculo")
	@JsonIgnore
	private List<PedidoVenda> pedidos;
	
	public Veiculo() {}
	
	public Veiculo(int codigo, String descricao, float valor) {
		super();
		this.codigo = codigo;
		this.descricao = descricao;
		this.valor = valor;
	}

	public int getId() {
		return id;
	}
	
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public List<PedidoVenda> getPedidos() {
		return pedidos;
	}

	public void setPedidos(List<PedidoVenda> pedidos) {
		this.pedidos = pedidos;
	}
	
}
