package com.trabalhoPoo.projetoRevendas.domain;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.JoinColumn;
import javax.persistence.FetchType;

@Entity
@Table(name = "PedidoVendatb")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})//erro1
public class PedidoVenda {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int codigo;
	private Date data;
	private float valorPedido;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "cliente")
	private Cliente cliente; 
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "vendedor")
	private Vendedor vendedor;
	@OneToMany(cascade = CascadeType.ALL, mappedBy="pedidovenda")
	@JsonIgnore//erro2
	private List<ItemPedido> item;
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "veiculos")
	private Veiculo veiculo;

	public PedidoVenda(int codigo, float valorPedido, Cliente cliente, Vendedor vendedor){//erro2
		super();
		this.codigo = codigo;
		this.data = d;
		this.valorPedido = valorPedido;
		this.cliente = cliente;
		this.vendedor = vendedor;
	}
	
	Calendar c = Calendar.getInstance();//erro2
	Date d = c.getTime();

	public int getId() {
		return id;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public float getValorPedido() {
		return valorPedido;
	}

	public void setValorPedido(float valorPedido) {
		this.valorPedido = valorPedido;
	}

	public List<ItemPedido> getItem() {
		return item;
	}

	public void setItem(List<ItemPedido> item) {
		this.item = item;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public Veiculo getVeiculo() {
		return veiculo;
	}

	public void setVeiculo(Veiculo veiculo) {
		this.veiculo = veiculo;
	}

	public float calcularPedido() {

		float valorPedido = 0;

		for (ItemPedido itens : this.item) {

			valorPedido += (itens.getValor() * itens.getQuantidade());
		}

		return valorPedido;
	}
	
}
