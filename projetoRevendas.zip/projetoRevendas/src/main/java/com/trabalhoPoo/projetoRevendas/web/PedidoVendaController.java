package com.trabalhoPoo.projetoRevendas.web;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.trabalhoPoo.projetoRevendas.domain.PedidoVendaRepositorio;
import com.trabalhoPoo.projetoRevendas.domain.PedidoVenda;

@RestController
public class PedidoVendaController {
	@Autowired
	private PedidoVendaRepositorio repositorio4;

	@RequestMapping(value = "/pedido", method = RequestMethod.GET)
    public Iterable<PedidoVenda> Get() {
        return repositorio4.findAll();
    }

    @RequestMapping(value = "/pedido/{id}", method = RequestMethod.GET)
    public ResponseEntity<PedidoVenda> GetById(@PathVariable(value = "id") long id)
    {
        Optional<PedidoVenda> pedido = repositorio4.findById(id);
        if(pedido.isPresent())
            return new ResponseEntity<PedidoVenda> (pedido.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/pedido", method =  RequestMethod.POST)
    public PedidoVenda Post(@Valid @RequestBody PedidoVenda pedido)
    {
        return repositorio4.save(pedido);
    }

    @RequestMapping(value = "/pedido/{id}", method =  RequestMethod.PUT)
    public ResponseEntity<PedidoVenda> Put(@PathVariable(value = "id") long id, @Valid @RequestBody PedidoVenda pv)
    {
        Optional<PedidoVenda> oldpedido = repositorio4.findById(id);
        if(oldpedido.isPresent()){
            PedidoVenda pedido = oldpedido.get();
            pedido.setCodigo(pv.getCodigo());
            pedido.setValorPedido(pv.getValorPedido());
            repositorio4.save(pedido);
            return new ResponseEntity<PedidoVenda>(pedido, HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/pedido/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<PedidoVenda> Delete(@PathVariable(value = "id") long id)
    {
        Optional<PedidoVenda> pedido = repositorio4.findById(id);
        if(pedido.isPresent()){
            repositorio4.delete(pedido.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
