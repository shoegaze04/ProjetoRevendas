package com.trabalhoPoo.projetoRevendas.domain;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name= "Vendedortb")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Vendedor {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	@OneToOne(cascade = CascadeType.ALL, mappedBy="vendedor")
	@JsonIgnore
	private PedidoVenda pedidos;
	private int codigo;
	private String nome;
	private float comissao;
	
	public Vendedor() {}
	
	public Vendedor(int codigo, String nome, float comissao) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.comissao = comissao;
	}
	
	public long getId() {
		return id;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public float getComissao() {
		return comissao;
	}

	public void setComissao(float comissao) {
		this.comissao = comissao;
	}

	public PedidoVenda getPedidos() {
		return pedidos;
	}

	public void setPedidos(PedidoVenda pedidos) {
		this.pedidos = pedidos;
	}
	
}
