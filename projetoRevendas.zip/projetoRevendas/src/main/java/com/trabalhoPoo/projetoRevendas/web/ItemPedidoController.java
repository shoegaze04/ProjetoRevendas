package com.trabalhoPoo.projetoRevendas.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trabalhoPoo.projetoRevendas.domain.ItemPedido;
import com.trabalhoPoo.projetoRevendas.domain.ItemPedidoRepositorio;

@RestController
public class ItemPedidoController {
	@Autowired
	private ItemPedidoRepositorio repositorio;
	@RequestMapping("/pedidos")
	public Iterable<ItemPedido> getPedidos() {
		return repositorio.findAll();
	}
}
