package com.trabalhoPoo.projetoRevendas.web;


import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.trabalhoPoo.projetoRevendas.domain.ItemPedido;
import com.trabalhoPoo.projetoRevendas.domain.ItemPedidoRepositorio;


@RestController
public class ItemPedidoController {
	@Autowired
	private ItemPedidoRepositorio repositorio5;

	@RequestMapping(value = "/item", method = RequestMethod.GET)
    public Iterable<ItemPedido> Get() {
        return repositorio5.findAll();
    }

    @RequestMapping(value = "/item/{id}", method = RequestMethod.GET)
    public ResponseEntity<ItemPedido> GetById(@PathVariable(value = "id") long id)
    {
        Optional<ItemPedido> item = repositorio5.findById(id);
        if(item.isPresent())
            return new ResponseEntity<ItemPedido>(item.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/item", method =  RequestMethod.POST)
    public ItemPedido Post(@Valid @RequestBody ItemPedido item)
    {
        return repositorio5.save(item);
    }

    @RequestMapping(value = "/item/{id}", method =  RequestMethod.PUT)
    public ResponseEntity<ItemPedido> Put(@PathVariable(value = "id") long id, @Valid @RequestBody ItemPedido i)
    {
        Optional<ItemPedido> olditem = repositorio5.findById(id);
        if(olditem.isPresent()){
            ItemPedido item = olditem.get();
            item.setSequencial(i.getSequencial());
            item.setQuantidade(i.getQuantidade());
            item.setDescricao(i.getDescricao());
            item.setValor(i.getValor());
            repositorio5.save(item);
            return new ResponseEntity<ItemPedido>(item, HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/item/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<ItemPedido> Delete(@PathVariable(value = "id") long id)
    {
        Optional<ItemPedido> item = repositorio5.findById(id);
        if(item.isPresent()){
            repositorio5.delete(item.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
