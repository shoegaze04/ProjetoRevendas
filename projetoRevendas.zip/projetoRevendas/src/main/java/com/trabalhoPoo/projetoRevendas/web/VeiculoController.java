package com.trabalhoPoo.projetoRevendas.web;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.trabalhoPoo.projetoRevendas.domain.Veiculo;
import com.trabalhoPoo.projetoRevendas.domain.VeiculoRepositorio;


@RestController
public class VeiculoController {
	@Autowired
	private VeiculoRepositorio repositorio3;
	
	@RequestMapping(value = "/veiculo", method = RequestMethod.GET)
    public Iterable<Veiculo> Get() {
        return repositorio3.findAll();
    }

    @RequestMapping(value = "/veiculo/{id}", method = RequestMethod.GET)
    public ResponseEntity<Veiculo> GetById(@PathVariable(value = "id") long id)
    {
        Optional<Veiculo> veiculo = repositorio3.findById(id);
        if(veiculo.isPresent())
            return new ResponseEntity<Veiculo>(veiculo.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/veiculo", method =  RequestMethod.POST)
    public Veiculo Post(@Valid @RequestBody Veiculo veiculo)
    {
        return repositorio3.save(veiculo);
    }

    @RequestMapping(value = "/veiculo/{id}", method =  RequestMethod.PUT)
    public ResponseEntity<Veiculo> Put(@PathVariable(value = "id") long id, @Valid @RequestBody Veiculo vc)
    {
        Optional<Veiculo> oldveiculo = repositorio3.findById(id);
        if(oldveiculo.isPresent()){
            Veiculo veiculo = oldveiculo.get();
            veiculo.setCodigo(vc.getCodigo());
            veiculo.setDescricao(vc.getDescricao());
            veiculo.setValor(vc.getValor());
            repositorio3.save(veiculo);
            return new ResponseEntity<Veiculo>(veiculo, HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/veiculo/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> Delete(@PathVariable(value = "id") long id)
    {
        Optional<Veiculo> veiculo = repositorio3.findById(id);
        if(veiculo.isPresent()){
            repositorio3.delete(veiculo.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
