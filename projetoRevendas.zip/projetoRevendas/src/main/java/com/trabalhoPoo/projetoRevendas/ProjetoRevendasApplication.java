package com.trabalhoPoo.projetoRevendas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import com.trabalhoPoo.projetoRevendas.domain.Cliente;
import com.trabalhoPoo.projetoRevendas.domain.ClienteRepositorio;
import com.trabalhoPoo.projetoRevendas.domain.ItemPedido;
import com.trabalhoPoo.projetoRevendas.domain.ItemPedidoRepositorio;
import com.trabalhoPoo.projetoRevendas.domain.PedidoVenda;
import com.trabalhoPoo.projetoRevendas.domain.PedidoVendaRepositorio;
import com.trabalhoPoo.projetoRevendas.domain.Veiculo;
import com.trabalhoPoo.projetoRevendas.domain.VeiculoRepositorio;
import com.trabalhoPoo.projetoRevendas.domain.Vendedor;
import com.trabalhoPoo.projetoRevendas.domain.VendedorRepositorio;

@SpringBootApplication
public class ProjetoRevendasApplication {
		
	@Autowired
		private ClienteRepositorio repositorio;
	@Autowired
		private VendedorRepositorio repositorio2;
	@Autowired
		private VeiculoRepositorio repositorio3;
	@Autowired
		private PedidoVendaRepositorio repositorio4;
	@Autowired
		private ItemPedidoRepositorio repositorio5;
	
		public static void main(String[] args) {
			SpringApplication.run(ProjetoRevendasApplication.class, args);
	}
		
	@Bean
	CommandLineRunner runner(){
		return args -> {
			
			Cliente c1 = new Cliente(001,"Francisco",01);
			Cliente c2 = new Cliente(002,"Ana",02);
			Cliente c3 = new Cliente(003,"Igor",03);
			
			repositorio.save(c1);
			repositorio.save(c2);
			repositorio.save(c3);
			
			Vendedor vd1 = new Vendedor(001,"Jake",45.0f);
			Vendedor vd2 = new Vendedor(002,"Tiago",10.0f);
			Vendedor vd3 = new Vendedor(003,"Helena",30.0f);

			repositorio2.save(vd1);
			repositorio2.save(vd2);
			repositorio2.save(vd3);
			
			
			Veiculo vc1 = new Veiculo(001,"Fiat",5000.0f);
			Veiculo vc2 = new Veiculo(002,"Ford",7000.0f);
			Veiculo vc3 = new Veiculo(003,"Toyota",9000.0f);
			
			repositorio3.save(vc1);
			repositorio3.save(vc2);
			repositorio3.save(vc3);
			
			PedidoVenda pv1 = new PedidoVenda(001,40.0f,c1,vd1,vc1);
			PedidoVenda pv2 = new PedidoVenda(002,50.0f,c2,vd2,vc2);			
			PedidoVenda pv3 = new PedidoVenda(003,60.0f,c3,vd3,vc3);
			
			repositorio4.save(pv1);
			repositorio4.save(pv2);
			repositorio4.save(pv3);
			
			ItemPedido ip1 = new ItemPedido(001,2,"Carro",5000.0f,pv1);
			ItemPedido ip2 = new ItemPedido(002,1,"Caminhão",2000.0f,pv2);
			ItemPedido ip3 = new ItemPedido(003,3,"Moto",3000.0f,pv3);
			
			repositorio5.save(ip1);
			repositorio5.save(ip2);
			repositorio5.save(ip3);
		};
	}
}
