package com.trabalhoPoo.projetoRevendas.domain;

import org.springframework.data.repository.CrudRepository;

public interface VeiculoRepositorio extends CrudRepository<Veiculo, Long>{
	
}
