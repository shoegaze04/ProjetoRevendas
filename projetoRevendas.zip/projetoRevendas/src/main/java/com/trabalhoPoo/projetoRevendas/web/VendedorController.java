package com.trabalhoPoo.projetoRevendas.web;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.trabalhoPoo.projetoRevendas.domain.Vendedor;
import com.trabalhoPoo.projetoRevendas.domain.VendedorRepositorio;


@RestController
public class VendedorController {
	@Autowired
	private VendedorRepositorio repositorio2;

	@RequestMapping(value = "/vendedor", method = RequestMethod.GET)
    public Iterable<Vendedor> Get() {
        return repositorio2.findAll();
    }

    @RequestMapping(value = "/vendedor/{id}", method = RequestMethod.GET)
    public ResponseEntity<Vendedor> GetById(@PathVariable(value = "id") long id)
    {
        Optional<Vendedor> vendedor = repositorio2.findById(id);
        if(vendedor.isPresent())
            return new ResponseEntity<Vendedor>(vendedor.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/vendedor", method =  RequestMethod.POST)
    public Vendedor Post(@Valid @RequestBody Vendedor vendedor)
    {
        return repositorio2.save(vendedor);
    }

    @RequestMapping(value = "/vendedor/{id}", method =  RequestMethod.PUT)
    public ResponseEntity<Vendedor> Put(@PathVariable(value = "id") long id, @Valid @RequestBody Vendedor vd)
    {
        Optional<Vendedor> oldvendedor = repositorio2.findById(id);
        if(oldvendedor.isPresent()){
            Vendedor vendedor = oldvendedor.get();
            vendedor.setCodigo(vd.getCodigo());
            vendedor.setNome(vd.getNome());
            vendedor.setComissao(vd.getComissao());
            repositorio2.save(vendedor);
            return new ResponseEntity<Vendedor>(vendedor, HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/vendedor/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> Delete(@PathVariable(value = "id") long id)
    {
        Optional<Vendedor> vendedor = repositorio2.findById(id);
        if(vendedor.isPresent()){
            repositorio2.delete(vendedor.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
