package com.trabalhoPoo.projetoRevendas.domain;

import org.springframework.data.repository.CrudRepository;

public interface VendedorRepositorio extends CrudRepository<Vendedor, Long>{

}
