package com.trabalhoPoo.projetoRevendas.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.OneToMany;
import java.util.List;
import javax.persistence.CascadeType;

@Entity
@Table(name= "Clientetb")
public class Cliente {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int codigo;
	private String nome;
	private int tipoCliente;
	@OneToMany(cascade = CascadeType.ALL, mappedBy="cliente")
	private List<PedidoVenda> pedidos;
	
	public Cliente() {}
	
	public Cliente(int codigo, String nome, int tipoCliente) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.tipoCliente = tipoCliente;
	}
	
	public int getId() {
		return id;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getTipoCliente() {
		return tipoCliente;
	}

	public void setTipoCliente(int tipoCliente) {
		this.tipoCliente = tipoCliente;
	}
	
	public List<PedidoVenda> getPedidos() {
		return pedidos;
	}

	public void setPedidos(List<PedidoVenda> pedidos) {
		this.pedidos = pedidos;
	}
	
}
